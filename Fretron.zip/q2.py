def distribute_apples():
    apple_weights = []
    while True:
        weight = int(input("Enter apple weight in gram (-1 to stop): "))
        if weight == -1:
            break
        apple_weights.append(weight)
    total_weight = sum(apple_weights)
    ram_weight_limit = total_weight * (50 / 100)
    sham_weight_limit = total_weight * (30 / 100)
    rahim_weight_limit = total_weight * (20 / 100)
    apple_weights.sort(reverse=True)
    ram_apples = []
    sham_apples = []
    rahim_apples = []

    for weight in apple_weights:
        if ram_weight_limit >= weight:
            ram_apples.append(weight)
            ram_weight_limit -= weight
        elif sham_weight_limit >= weight:
            sham_apples.append(weight)
            sham_weight_limit -= weight
        elif rahim_weight_limit >= weight:
            rahim_apples.append(weight)
            rahim_weight_limit -= weight
    print("Distribution Result:")
    print("Ram:", *ram_apples)
    print("Sham:", *sham_apples)
    print("Rahim:", *rahim_apples)

distribute_apples()
