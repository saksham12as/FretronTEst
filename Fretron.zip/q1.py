import matplotlib.pyplot as plt
flight1 = [(1,1), (2,2), (3,3)]
flight2 = [(1,1), (2,4), (3,2)]
flight3 = [(1,1), (4,2), (3,4)]
x1, y1 = zip(*flight1)
x2, y2 = zip(*flight2)
x3, y3 = zip(*flight3)

plt.plot(x1, y1, marker='o', label='Flight 1')
plt.plot(x2, y2, marker='o', label='Flight 2')
plt.plot(x3, y3, marker='', label='Flight 3')
plt.xlabel('X Coordinate')
plt.ylabel('Y Coordinate')
plt.title('Non-intersecting Flight Paths')
plt.legend()
plt.grid(True)
plt.show()
